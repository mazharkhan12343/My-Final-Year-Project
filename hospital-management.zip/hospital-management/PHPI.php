<?php 
echo 'PHP version: ' . phpversion();
phpinfo();
?>